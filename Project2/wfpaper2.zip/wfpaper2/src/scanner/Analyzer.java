/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package scanner;

/**
 *
 * @author Administrator
 */
import java.io.File;
import java.io.RandomAccessFile;
import java.util.HashMap;

public class Analyzer {

	private Scaner scaner;
	private File testFile;
    public static final String testFileAdd = "D:\\Sample.java";    //the exact address for test file	
    private RandomAccessFile fileReandomReader;
	public void initAnalayzer() {
		this.scaner = new Scaner();

		try {
			testFile = new File(testFileAdd);
			this.fileReandomReader = new RandomAccessFile(testFile, "r");
		} catch (Exception e) {
			System.out.println("Cannot find Sample.java!");
		}
	}

	public void startAnalyze() {
		String tmpString = "";
		String result;
		int row = 0;
		System.out.println("······················Analyzing·····················");
		try {
			while ((tmpString = this.fileReandomReader.readLine()) != null) {
				++row;
				System.out.println("·····················analyze row " + row
						+ "·················");
				// System.err.println(tmpString + "!! " +row);
				result = scaner.scan(tmpString);
				System.out.println(result);
				scaner.cleanScaner();
				tmpString = "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Analyzer a = new Analyzer();
		a.initAnalayzer();
		a.startAnalyze();
	}
}




