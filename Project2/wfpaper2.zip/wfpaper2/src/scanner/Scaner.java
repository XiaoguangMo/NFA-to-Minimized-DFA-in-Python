package scanner;

import java.util.HashMap;
import java.util.Map;



public class Scaner {

	private char ch;
	private String token;
	private String result;
	private int index = 0;
	private char[] strChar = new char[1000];
	private int rowLength = 0;
//	private KeywordConfig keywordConfig;
//	private PunctuationConfig punctuationConfig;
	private Map<String , Integer> keywords;
	private Map<String , String> punctuations;

	public Scaner() {
		this.result = "";
//		this.keywordConfig = new KeywordConfig();
//		this.punctuationConfig = new PunctuationConfig();
		this.keywords = new HashMap<String , Integer>();
			keywords.put("while", 1);         keywords.put("do", 2);
			keywords.put("public", 3);        keywords.put("class", 4);
			keywords.put("static", 5);        keywords.put("new", 6);
			keywords.put("void", 7);          keywords.put("int", 8);
			keywords.put("for", 9);           keywords.put("system", 10);
			keywords.put("if", 11);			  keywords.put("boolean", 12);
			keywords.put("double", 13);		  keywords.put("char", 14);
			keywords.put("String", 15);		  keywords.put("this", 16);

		this.punctuations = new HashMap<String , String>();
		    punctuations.put("+", "Plus");        punctuations.put("-", "Subtraction");
		    punctuations.put("*", "Star");        punctuations.put("/", "Division");
		    punctuations.put("(", "Open Parentheses");    punctuations.put(")", "Close Parentheses");
		    punctuations.put("{", "Open Brace");    punctuations.put("}", "Close Brace");
		    punctuations.put("[", "Open Square Brackets");    punctuations.put("]", "Close Square Brackets");
		    punctuations.put(",", "Comma");        punctuations.put(".", "Point");
		    punctuations.put(";", "Semicolon");        punctuations.put("%", "Percentage");
		    punctuations.put("\'", "Single Quotes");      punctuations.put("\"", "Double Quotes");
	}

	public String scan(String rowString) {
		strChar = rowString.toCharArray();
		rowLength = strChar.length;
		while (this.index <= rowLength) {
			this.token = "";
			this.ch = this.getBC(strChar);

			if (this.ch == ';') {
				break;
			} else if (java.lang.Character.isLetter(ch)) {
				this.token = this.contact(token, ch);
				ch = this.getNextChar(strChar);
				while ((java.lang.Character.isLetter(ch)) || (java.lang.Character.isDigit(ch))) {
					this.token = this.contact(token, ch);
					ch = this.getNextChar(strChar);
				}
				this.index--;
				// System.err.println("!!!"+this.token);
				if (this.findKeyword(token)) {
					this.result += "[Reserved Word]  " + this.token.toString() + "\n";
				} else
					this.result += "[Identifier]  " + this.token.toString() + "\n";

				this.token = "";
			} else if (java.lang.Character.isDigit(ch)) {
				this.token = this.contact(token, ch);
				ch = this.getNextChar(strChar);
				while (java.lang.Character.isDigit(ch)) {
					this.token = this.contact(token, ch);
					ch = this.getNextChar(strChar);
				}
				this.index--;

				this.result += "[Number]  " + this.token.toString() + "\n";

				this.token = "";
			} else {
				String key = String.valueOf(ch);
				if (this.findPunctuation(key)) {
					this.result += "[" + this.getPunctuation(key)
							+ "]  " + key + "\n";
				} else if (key.equals(" ") || key.equals("        ")) {
					break;
				} else
					this.result += "[Undefined Symbol]  " + key + "\n";
				this.token = "";
			}
		}
		return result;
	}

	public void cleanScaner() {
		this.ch = ' ';
		this.index = 0;
		this.result = "";
		this.rowLength = 0;
		this.strChar = null;
	}

	public char getBC(char[] strChar) {
		try {
			while ((strChar[this.index]) == ' ') {
				this.index++;
			}
			this.index++;
		} catch (ArrayIndexOutOfBoundsException e) {
			return ';';
		}
		return strChar[this.index - 1];
	}

	public char getNextChar(char[] strChar) {
		this.index++;
		return strChar[this.index - 1];
	}

	public String contact(String token, char ch) {
		return token + String.valueOf(ch);
	}

	public boolean findKeyword(String str){
		if(this.keywords.containsKey(str)){
			return true;
		}
	    return false;
	}

	public boolean findPunctuation(String str){
		if(this.punctuations.containsKey(str)){
			return true;
		}
		else return false;
	}

	public String getPunctuation(String str){
		return this.punctuations.get(str);
	}
}